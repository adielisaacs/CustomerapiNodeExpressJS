module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "adiel123",
  DB: "nodejs"
};

require('dotenv').config();

console.log(process.env.USER_ID); // "239482"
console.log(process.env.USER_KEY); // "foobar"
console.log(process.env.NODE_ENV); // "development"

console.log("");

process.argv.forEach((val, index) => {
   console.log(`${index}: ${val}`)
 })


 const readline = require('readline').createInterface({
   input: process.stdin,
   output: process.stdout
 })
 
 readline.question(`What's your name?`, name => {
   console.log(`Hi ${name}!`)
   readline.close()
 })


 
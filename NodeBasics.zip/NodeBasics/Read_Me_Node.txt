A Node.js application consists of the following three important components −

Import required modules 

− We use the require directive to load Node.js modules.

Create server 

− A server which will listen to client's requests similar to Apache HTTP Server.

Read request and return response 

− The server created in an earlier step will read the HTTP request made by the client which can be a browser or a console and return the response.

----
NPM |
----
update command t the latest version

$ sudo npm install npm -g

uninstall 
---------

$ npm uninstall express

Update 
------

$ npm update express

Search 
------

$ npm search express

------------------
Creating a Module | register your module with Node JS
------------------

$ npm init

add user 
--------

$ npm adduser

$ npm publish


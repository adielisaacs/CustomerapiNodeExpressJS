//Callbacks and file reads
//-------------------------
//blocking code Example waits for file to be read first 
var fs = require("fs");
var data = fs.readFileSync("input.txt");

console.log(data.toString());
console.log("Block Program Ended");

//Non - Blocking code doesnt wait for the file read 
fs.readFile('input.txt', function (err, data) {
   if (err) return console.error(err);
   console.log(data.toString());
});

console.log("Non Blocking Program Ended");
console.log("");

// promise
const fileName = 'input.txt';
const getFile = (fileName) => {
   return new Promise((resolve, reject) => {
     fs.readFile(fileName, (err, data) => {
       if (err) {
         reject(err);  // calling `reject` will cause the promise to fail with or without the error passed as an argument
         return        // and we don't want to go any further
       }
       resolve(data);
     })
   })
 }
 console.log("Promise Program Ended >>"+getFile);